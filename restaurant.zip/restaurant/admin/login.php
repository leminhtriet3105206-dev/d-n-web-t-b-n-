<?php
require_once '../core/config.php';
require_once '../core/database.php';

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $db = Database::getInstance();
    $stmt = $db->query("SELECT * FROM admins WHERE username = ?", [$username], "s");
    $admin = $stmt->get_result()->fetch_assoc();

    
    if ($admin && $password == $admin['password']) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['full_name'];
        $_SESSION['admin_role'] = $admin['role']; 
        $_SESSION['admin_avatar'] = $admin['avatar_url'];
            
        header('Location: index.php');
        exit;
    } else {
        $error = 'Tên đăng nhập hoặc mật khẩu không chính xác!';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập Quản trị</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <h1>Hệ Thống Quản Trị</h1>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Tên đăng nhập:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Mật khẩu:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <?php if ($error): ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
            <button type="submit" class="btn">Đăng nhập</button>
        </form>
        <p style="margin-top: 1.5rem;">Chưa có tài khoản? <a href="register.php">Đăng ký ngay</a></p>
    </div>
</body>
</html>