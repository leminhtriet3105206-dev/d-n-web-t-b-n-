<?php
// File: /admin/manage_reservations.php

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/../core/email_service.php';

$db = Database::getInstance();


if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}


$where_clauses = []; $params = []; $types = "";
$filter_keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
$filter_date = isset($_GET['date']) ? $_GET['date'] : '';
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';

$query_params = $_GET; 
unset($query_params['action'], $query_params['id'], $query_params['page']);
$query_string = http_build_query($query_params);

if (!empty($filter_keyword)) {
    $where_clauses[] = "(r.customer_name LIKE ? OR r.customer_phone LIKE ? OR r.id = ?)";
    $params[] = "%$filter_keyword%"; $params[] = "%$filter_keyword%"; $params[] = $filter_keyword;
    $types .= "sss";
}
if (!empty($filter_date)) { $where_clauses[] = "DATE(r.reservation_time) = ?"; $params[] = $filter_date; $types .= "s"; }
if (!empty($filter_status)) { $where_clauses[] = "r.status = ?"; $params[] = $filter_status; $types .= "s"; }
$sql_where = !empty($where_clauses) ? " WHERE " . implode(" AND ", $where_clauses) : "";


if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];
    $new_status = ($action == 'confirm') ? 'confirmed' : (($action == 'cancel') ? 'cancelled' : '');

    if (!empty($new_status)) {
        $info_stmt = $db->query("SELECT r.*, t.name as table_name FROM reservations r JOIN tables t ON r.table_id = t.id WHERE r.id = ?", [$id], "i");
        $reservation_info = $info_stmt->get_result()->fetch_assoc();

        if ($reservation_info) {
            $items_stmt = $db->query("SELECT ri.quantity, ri.price_at_reservation, mi.name as item_name FROM reservation_items ri JOIN menu_items mi ON ri.menu_item_id = mi.id WHERE ri.reservation_id = ?", [$id], "i");
            $ordered_items = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $total_amount = 0;
            foreach ($ordered_items as $item) $total_amount += $item['quantity'] * $item['price_at_reservation'];

            $update_stmt = $db->query("UPDATE reservations SET status = ? WHERE id = ?", [$new_status, $id], "si");
            if ($update_stmt) {
                send_reservation_email($reservation_info, $ordered_items, $total_amount, $new_status);
                $_SESSION['message'] = '<p class="success">Cập nhật trạng thái thành công!</p>';
            }
        }
    }
    header('Location: manage_reservations.php?' . $query_string . '&page=' . ($_GET['page'] ?? 1));
    exit;
}


$limit = 5; 
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1; 
$offset = ($page - 1) * $limit; 

$count_sql = "SELECT COUNT(*) as total FROM reservations r " . $sql_where;
$count_stmt = $db->query($count_sql, $params, $types);
$total_results = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_results / $limit);

$params[] = $limit; $params[] = $offset; $types .= "ii";
$sql_final = "SELECT r.*, t.name as table_name FROM reservations r JOIN tables t ON r.table_id = t.id $sql_where ORDER BY r.created_at DESC LIMIT ? OFFSET ?";
$stmt = $db->query($sql_final, $params, $types);
$reservations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<style>
    .search-box { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); margin-bottom: 20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end; }
    .search-group { flex: 1; min-width: 200px; }
    .search-group label { display: block; margin-bottom: 5px; font-weight: 500; font-size: 0.9rem; }
    .search-group input, .search-group select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px; }
    .search-btn, .reset-btn { padding: 9px 20px; color: white; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block;}
    .search-btn { background-color: var(--primary-color); } .reset-btn { background-color: #6c757d; }
    .pagination-wrapper { display: flex; justify-content: center; margin-top: 2rem; margin-bottom: 2rem; }
    .pagination { display: flex; align-items: center; gap: 5px; background: #fff; padding: 8px; border-radius: 50px; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05); }
    .page-link { display: flex; align-items: center; justify-content: center; min-width: 36px; height: 36px; padding: 0 5px; border-radius: 50%; text-decoration: none; font-weight: 600; font-size: 0.9rem; color: var(--dark-color); transition: all 0.2s ease; border: 2px solid transparent; }
    .page-link:hover { background-color: #f0f2f5; color: var(--primary-color); transform: translateY(-2px); }
    .page-link.active { background-color: var(--primary-color); color: #fff; box-shadow: 0 4px 10px rgba(0, 123, 255, 0.3); }
    .page-link.disabled { color: #ccc; pointer-events: none; cursor: default; }
    .page-link svg { width: 16px; height: 16px; fill: currentColor; }
    td { vertical-align: middle; }
</style>

<div class="container">
    <h1>Quản lý Đặt Bàn</h1>
    
    <form method="GET" action="manage_reservations.php" class="search-box">
        <div class="search-group"><label>Từ khóa:</label><input type="text" name="keyword" value="<?php echo htmlspecialchars($filter_keyword); ?>" placeholder="Tên, SĐT, Mã..."></div>
        <div class="search-group"><label>Ngày đặt:</label><input type="date" name="date" value="<?php echo htmlspecialchars($filter_date); ?>"></div>
        <div class="search-group"><label>Trạng thái:</label><select name="status"><option value="">-- Tất cả --</option><option value="pending" <?php if($filter_status=='pending') echo 'selected'; ?>>Chờ duyệt</option><option value="confirmed" <?php if($filter_status=='confirmed') echo 'selected'; ?>>Đã duyệt</option><option value="cancelled" <?php if($filter_status=='cancelled') echo 'selected'; ?>>Đã hủy</option></select></div>
        <div style="padding-bottom: 1px;"><button type="submit" class="search-btn">Tìm kiếm</button> <a href="manage_reservations.php" class="reset-btn">Đặt lại</a></div>
    </form>

    <table>
        <thead>
            <tr>
                <th>Mã</th>
                <th>Khách Hàng</th>
                <th>SĐT</th>
                <th>Thời gian</th>
                <th>Bàn</th>
                <th>Khách</th>
                <th>Món đã chọn</th>
                <th>Ghi chú</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th style="text-align:center;">Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($reservations)): ?>
                <tr><td colspan="11" style="text-align: center; padding: 20px;">Không tìm thấy dữ liệu.</td></tr>
            <?php else: ?>
                <?php foreach ($reservations as $r): ?>
                <tr>
                    <td>#<?php echo $r['id']; ?></td>
                    <td><?php echo htmlspecialchars($r['customer_name']); ?></td>
                    <td><?php echo htmlspecialchars($r['customer_phone']); ?></td>
                    
                    <td>
                        <?php 
                            
                            if (empty($r['reservation_time']) || $r['reservation_time'] == '0000-00-00 00:00:00') {
                                echo '<span style="color:red; font-size:0.8rem;">Lỗi ngày (Đơn cũ)</span>';
                            } else {
                                echo date('d/m/Y H:i', strtotime($r['reservation_time']));
                            }
                        ?>
                    </td>
                    
                    <td><?php echo htmlspecialchars($r['table_name']); ?></td>
                    <td><?php echo $r['num_guests']; ?></td>
                    <td>
                        <?php
                        $items_stmt = $db->query("SELECT ri.quantity, ri.price_at_reservation, mi.name as item_name FROM reservation_items ri JOIN menu_items mi ON ri.menu_item_id = mi.id WHERE ri.reservation_id = ?", [$r['id']], "i");
                        $ordered_items = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                        $total_amount = 0;
                        if (!empty($ordered_items)) {
                            echo '<ul style="padding-left: 20px; margin: 0; font-size: 0.9rem;">';
                            foreach ($ordered_items as $item) {
                                echo '<li>' . htmlspecialchars($item['item_name']) . ' <b>x' . $item['quantity'] . '</b></li>';
                                $total_amount += $item['quantity'] * $item['price_at_reservation'];
                            }
                            echo '</ul>';
                        } else { echo '<span style="color:#999">--</span>'; }
                        ?>
                    </td>
                    <td style="max-width: 150px; font-size: 0.85rem;">
                        <?php echo !empty($r['notes']) ? nl2br(htmlspecialchars($r['notes'])) : '<span style="color:#ccc">--</span>'; ?>
                    </td>
                    <td style="font-weight: bold; color: #28a745; min-width: 90px;"><?php echo number_format($total_amount); ?> đ</td>
                    <td>
                        <?php if ($r['status'] == 'confirmed'): ?>
                            <span class="status-badge status-confirmed"><svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg> Đã duyệt</span>
                        <?php elseif ($r['status'] == 'cancelled'): ?>
                            <span class="status-badge status-cancelled"><svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg> Đã hủy</span>
                        <?php else: ?>
                            <span class="status-badge status-pending"><svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg> Chờ duyệt</span>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: center;">
                        <?php if ($r['status'] == 'pending'): ?>
                            <div style="display: flex; gap: 8px; justify-content: center;">
                                <a href="?action=confirm&id=<?php echo $r['id']; ?>&<?php echo $query_string; ?>&page=<?php echo $page; ?>" class="btn-action confirm" title="Duyệt đơn"><svg viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg></a>
                                <a href="?action=cancel&id=<?php echo $r['id']; ?>&<?php echo $query_string; ?>&page=<?php echo $page; ?>" class="btn-action cancel" title="Hủy đơn"><svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg></a>
                            </div>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <?php if ($total_pages > 1): ?>
    <div class="pagination-wrapper">
        <div class="pagination">
            <?php 
            $prev_disabled = ($page <= 1) ? 'disabled' : '';
            $prev_url = ($page > 1) ? "?page=" . ($page - 1) . "&" . $query_string : '#';
            ?>
            <a href="<?php echo $prev_url; ?>" class="page-link <?php echo $prev_disabled; ?>"><svg viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg></a>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <?php if ($i == 1 || $i == $total_pages || ($i >= $page - 2 && $i <= $page + 2)): ?>
                    <a href="?page=<?php echo $i; ?>&<?php echo $query_string; ?>" class="page-link <?php echo ($i == $page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php elseif ($i == $page - 3 || $i == $page + 3): ?><span class="page-dots">...</span><?php endif; ?>
            <?php endfor; ?>
            <?php 
            $next_disabled = ($page >= $total_pages) ? 'disabled' : '';
            $next_url = ($page < $total_pages) ? "?page=" . ($page + 1) . "&" . $query_string : '#';
            ?>
            <a href="<?php echo $next_url; ?>" class="page-link <?php echo $next_disabled; ?>"><svg viewBox="0 0 24 24"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg></a>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>