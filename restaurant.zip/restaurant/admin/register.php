<?php
require_once '../core/config.php';
require_once '../core/database.php';

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];
    $email = trim($_POST['email']);
    $full_name = trim($_POST['full_name']);
    $restaurant_name = trim($_POST['restaurant_name']);
   
    $phone = trim($_POST['phone']);
    $dob = trim($_POST['dob']);

    if (empty($username) || empty($password) || empty($password_confirm) || empty($email) || empty($full_name)) {
        $error = 'Vui lòng điền đầy đủ các trường bắt buộc (*).';
    } elseif ($password !== $password_confirm) {
        $error = 'Mật khẩu xác nhận không khớp.';
    } elseif (strlen($password) < 6) {
        $error = 'Mật khẩu phải có ít nhất 6 ký tự.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Địa chỉ email không hợp lệ.';
    } else {
        $db = Database::getInstance();
        $stmt_user = $db->query("SELECT id FROM admins WHERE username = ?", [$username], "s");
        if ($stmt_user->get_result()->num_rows > 0) {
            $error = 'Tên đăng nhập này đã được sử dụng.';
        } else {
            $stmt_email = $db->query("SELECT id FROM admins WHERE email = ?", [$email], "s");
            if ($stmt_email->get_result()->num_rows > 0) {
                $error = 'Địa chỉ email này đã được sử dụng.';
            } else {
                
                
                $plain_password = $password; 
                $default_role = 'staff';
                
                
                $sql = "INSERT INTO admins (username, password, full_name, email, restaurant_name, phone, dob, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt_insert = $db->query($sql, [$username, $plain_password, $full_name, $email, $restaurant_name, $phone, $dob, $default_role], "ssssssss");

                if ($stmt_insert) {
                    $success = 'Đăng ký thành công! Bạn có thể đăng nhập ngay bây giờ.';
                } else {
                    $error = 'Đã có lỗi xảy ra trong quá trình đăng ký. Vui lòng thử lại.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký Tài khoản Quản trị</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body class="login-page">
    <div class="login-container" style="max-width: 500px;">
        <h1>Đăng ký Tài khoản Nhân viên</h1>

        <?php if ($error): ?><p class="error"><?php echo $error; ?></p><?php endif; ?>
        <?php if ($success): ?><p class="success"><?php echo $success; ?></p><?php endif; ?>

        <?php if (!$success): ?>
        <form action="register.php" method="POST">
            <div class="form-group">
                <label for="username">Tên đăng nhập (*):</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="password">Mật khẩu (*):</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="password_confirm">Xác nhận mật khẩu (*):</label>
                <input type="password" id="password_confirm" name="password_confirm" required>
            </div>
            <div class="form-group">
                <label for="full_name">Họ và Tên (*):</label>
                <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>" required>
            </div>
             <div class="form-group">
                <label for="email">Email (*):</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="phone">Số điện thoại:</label>
                <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="dob">Ngày sinh:</label>
                <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($_POST['dob'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="restaurant_name">Tên nhà hàng (Tùy chọn):</label>
                <input type="text" id="restaurant_name" name="restaurant_name" value="<?php echo htmlspecialchars($_POST['restaurant_name'] ?? ''); ?>">
            </div>

            <button type="submit" class="btn">Đăng ký</button>
        </form>
        <?php endif; ?>

        <p style="margin-top: 1.5rem;">Đã có tài khoản? <a href="login.php">Đăng nhập tại đây</a></p>
    </div>
</body>
</html>