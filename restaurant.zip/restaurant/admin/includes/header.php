<?php

require_once __DIR__ . '/check_admin.php';
require_once __DIR__ . '/../../core/database.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang Quản Trị</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/admin_style.css">
</head>
<body>
    <header class="admin-header">
        <div class="container">
            <div class="logo">TRANG QUẢN TRỊ</div>
            
            <nav class="admin-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_reservations.php">Quản lý Đặt Bàn</a></li>
                    <li><a href="manage_menu.php">Quản lý Thực Đơn</a></li>
                    <?php if (isset($_SESSION['admin_role']) && $_SESSION['admin_role'] == 'admin'): ?>
                        <li><a href="manage_staff.php">Quản lý Nhân viên</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            
            <div class="admin-user">
                <a href="manage_staff.php?edit_id=<?php echo $_SESSION['admin_id']; ?>" class="header-profile-link">
                    <?php if (!empty($_SESSION['admin_avatar'])): ?>
                        <img src="<?php echo BASE_URL; ?>/assets/images/avatars/<?php echo htmlspecialchars($_SESSION['admin_avatar']); ?>" alt="Avatar" class="header-avatar">
                    <?php else: ?>
                        <svg class="header-avatar default-avatar" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                    <?php endif; ?>
                </a>
                
                <a href="manage_staff.php?edit_id=<?php echo $_SESSION['admin_id']; ?>" class="header-profile-name">
                    Chào, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                </a>

                <a href="logout.php" class="header-logout-link">Đăng xuất</a>
            </div>
        </div>
    </header>
    <main class="admin-main">