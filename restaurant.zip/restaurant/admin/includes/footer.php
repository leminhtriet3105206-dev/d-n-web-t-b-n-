</main>
    <footer class="admin-footer">
        <div class="container">
            <p>&copy; 2025 Admin Panel</p>
        </div>
    </footer>
</body>
</html>