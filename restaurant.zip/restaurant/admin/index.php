<?php
// File: /admin/index.php

require_once __DIR__ . '/includes/header.php';

$db = Database::getInstance();


$pending_stmt = $db->query("SELECT COUNT(*) as count FROM reservations WHERE status='pending'");
$pending_count = $pending_stmt->get_result()->fetch_assoc()['count'];

$confirmed_stmt = $db->query("SELECT COUNT(*) as count FROM reservations WHERE status='confirmed'");
$confirmed_count = $confirmed_stmt->get_result()->fetch_assoc()['count'];

$menu_item_stmt = $db->query("SELECT COUNT(*) as count FROM menu_items");
$menu_item_count = $menu_item_stmt->get_result()->fetch_assoc()['count'];


$revenue_sql = "
    SELECT SUM(ri.quantity * ri.price_at_reservation) as total_revenue
    FROM reservations r
    JOIN reservation_items ri ON r.id = ri.reservation_id
    WHERE r.status = 'confirmed'
";
$revenue_stmt = $db->query($revenue_sql);
$total_revenue = $revenue_stmt->get_result()->fetch_assoc()['total_revenue'] ?? 0;


$daily_revenue_sql = "
    SELECT 
        DATE(r.reservation_time) as revenue_date, 
        COUNT(DISTINCT r.id) as total_orders,
        SUM(ri.quantity * ri.price_at_reservation) as daily_total
    FROM reservations r
    JOIN reservation_items ri ON r.id = ri.reservation_id
    WHERE r.status = 'confirmed' 
    AND r.reservation_time IS NOT NULL 
    AND r.reservation_time > '1970-01-01'
    GROUP BY DATE(r.reservation_time)
    ORDER BY revenue_date DESC
    LIMIT 7
";
$daily_revenue_stmt = $db->query($daily_revenue_sql);
$daily_revenues = $daily_revenue_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<style>
    
    .dashboard-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 20px;
        margin-bottom: 40px;
    }
    .stat-card {
        background: #fff;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
        display: flex;
        flex-direction: column;
        justify-content: center;
        border-left: 5px solid transparent;
        transition: transform 0.2s;
    }
    .stat-card:hover { transform: translateY(-5px); }
    
    .stat-card h2 { margin: 0; font-size: 2.5rem; color: #333; }
    .stat-card p { margin: 5px 0 0; color: #666; font-size: 1.1rem; font-weight: 500; }

    .card-pending { border-left-color: #ffc107; }
    .card-pending h2 { color: #ffc107; }

    .card-confirmed { border-left-color: #28a745; }
    .card-confirmed h2 { color: #28a745; }

    .card-menu { border-left-color: #17a2b8; }
    .card-menu h2 { color: #17a2b8; }

    .card-revenue { border-left-color: #6f42c1; }
    .card-revenue h2 { color: #6f42c1; font-size: 2rem; }

    .revenue-section {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }
    .revenue-section h3 { margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 15px; }
</style>

<div class="container">
    <h1 style="margin-bottom: 30px;">Bảng điều khiển</h1>
    
    <div class="dashboard-stats">
        <div class="stat-card card-revenue">
            <h2><?php echo number_format($total_revenue); ?> đ</h2>
            <p>Tổng Doanh Thu</p>
        </div>
        <div class="stat-card card-pending">
            <h2><?php echo $pending_count; ?></h2>
            <p>Đơn chờ duyệt</p>
        </div>
        <div class="stat-card card-confirmed">
            <h2><?php echo $confirmed_count; ?></h2>
            <p>Đơn đã duyệt</p>
        </div>
        <div class="stat-card card-menu">
            <h2><?php echo $menu_item_count; ?></h2>
            <p>Món ăn</p>
        </div>
    </div>

    <div class="revenue-section">
        <h3>Doanh thu 7 ngày có đơn gần nhất</h3>
        <table>
            <thead>
                <tr>
                    <th>Ngày</th>
                    <th>Số đơn đã duyệt</th>
                    <th>Doanh thu ngày</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($daily_revenues)): ?>
                    <tr><td colspan="3" style="text-align: center;">Chưa có dữ liệu doanh thu.</td></tr>
                <?php else: ?>
                    <?php foreach ($daily_revenues as $day): ?>
                    <tr>
                        <td>
                            <?php 
                               
                                if (!empty($day['revenue_date'])) {
                                    echo date('d/m/Y', strtotime($day['revenue_date'])); 
                                } else {
                                    echo 'N/A';
                                }
                            ?>
                        </td>
                        <td><?php echo $day['total_orders']; ?> đơn</td>
                        <td style="font-weight: bold; color: #6f42c1;">
                            <?php echo number_format($day['daily_total']); ?> VNĐ
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>