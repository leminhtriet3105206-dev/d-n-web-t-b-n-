<?php
// File: /admin/manage_staff.php

require_once __DIR__ . '/includes/header.php';


if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$db = Database::getInstance();
$message = '';


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action == 'edit') {
        $user_id = (int)$_POST['id'];
        $full_name = trim($_POST['full_name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $dob = trim($_POST['dob']);
        $role = trim($_POST['role']);
        $avatar_url = $_POST['current_avatar'] ?? null;

        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == UPLOAD_ERR_OK) {
            if (!is_dir(AVATAR_UPLOAD_DIR)) {
                mkdir(AVATAR_UPLOAD_DIR, 0755, true);
            }
            $fileTmpPath = $_FILES['avatar']['tmp_name'];
            $fileName = $_FILES['avatar']['name'];
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedfileExtensions = ['jpg', 'gif', 'png', 'jpeg'];
            if (in_array($fileExtension, $allowedfileExtensions)) {
                $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                $destPath = AVATAR_UPLOAD_DIR . $newFileName;
                if (move_uploaded_file($fileTmpPath, $destPath)) {
                    if ($avatar_url && file_exists(AVATAR_UPLOAD_DIR . $avatar_url)) {
                        unlink(AVATAR_UPLOAD_DIR . $avatar_url);
                    }
                    $avatar_url = $newFileName;
                } else {
                    $message .= '<p class="error">Lỗi khi di chuyển file ảnh.</p>';
                }
            } else {
                $message .= '<p class="error">Chỉ chấp nhận ảnh JPG, JPEG, PNG, GIF.</p>';
            }
        }

        $sql = "UPDATE admins SET full_name = ?, email = ?, phone = ?, dob = ?, role = ?, avatar_url = ? WHERE id = ?";
        $db->query($sql, [$full_name, $email, $phone, $dob, $role, $avatar_url, $user_id], "ssssssi");
        $message .= '<p class="success">Cập nhật thông tin nhân viên thành công!</p>';
        
      
        if ($user_id == $_SESSION['admin_id']) {
            $_SESSION['admin_name'] = $full_name;
            $_SESSION['admin_avatar'] = $avatar_url;
        }

    } elseif ($action == 'delete' && isset($_POST['id'])) {
        $user_id = (int)$_POST['id'];
        if ($user_id == $_SESSION['admin_id']) {
            $message .= '<p class="error">Bạn không thể tự xóa chính mình.</p>';
        } else {
            $avatar_stmt = $db->query("SELECT avatar_url FROM admins WHERE id = ?", [$user_id], "i");
            $avatar_result = $avatar_stmt->get_result()->fetch_assoc();
            if ($avatar_result && !empty($avatar_result['avatar_url'])) {
                $avatar_path = AVATAR_UPLOAD_DIR . $avatar_result['avatar_url'];
                if (file_exists($avatar_path)) {
                    unlink($avatar_path);
                }
            }
            $db->query("DELETE FROM admins WHERE id = ?", [$user_id], "i");
            $message .= '<p class="success">Xóa nhân viên thành công!</p>';
        }
    }
}


$edit_user = null;
if (isset($_GET['edit_id'])) {
    $edit_id = (int)$_GET['edit_id'];
    $edit_stmt = $db->query("SELECT * FROM admins WHERE id = ?", [$edit_id], "i");
    $edit_user = $edit_stmt->get_result()->fetch_assoc();
}


$staff_stmt = $db->query("SELECT * FROM admins ORDER BY full_name");
$staff_list = $staff_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<div id="modal-overlay" class="modal-overlay <?php echo ($edit_user ? '' : 'hidden'); ?>"></div>

<div id="profile-modal" class="modal-container <?php echo ($edit_user ? '' : 'hidden'); ?>">
    <div class="form-card">
        <button id="close-modal-btn" class="modal-close-btn">&times;</button>

        <h2>Chỉnh sửa Profile Nhân viên</h2>
        
        <form id="profile-form" action="manage_staff.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="edit-id" value="<?php echo htmlspecialchars($edit_user['id'] ?? ''); ?>">
            <input type="hidden" name="current_avatar" id="edit-current_avatar" value="<?php echo htmlspecialchars($edit_user['avatar_url'] ?? ''); ?>">

            <div class="form-group">
                <label>Ảnh đại diện hiện tại:</label>
                <img src="<?php echo BASE_URL; ?>/assets/images/avatars/default.png" alt="Avatar" id="edit-avatar-img" style="width: 100px; height: 100px; object-fit: cover; border-radius: 50%; display: none;">
                <p id="edit-avatar-none" style="display: block;">Chưa có ảnh đại diện.</p>
            </div>
            
            <div class="form-group">
                <label for="avatar">Tải ảnh đại diện mới:</label>
                <input type="file" id="avatar" name="avatar" accept="image/*">
            </div>
            
            <div class="form-group">
                <label for="username">Tên đăng nhập (Không thể đổi):</label>
                <input type="text" id="edit-username" name="username" value="<?php echo htmlspecialchars($edit_user['username'] ?? ''); ?>" disabled>
            </div>
            
            <div class="form-group">
                <label for="full_name">Họ và Tên:</label>
                <input type="text" id="edit-full_name" name="full_name" value="<?php echo htmlspecialchars($edit_user['full_name'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="edit-email" name="email" value="<?php echo htmlspecialchars($edit_user['email'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="phone">Số điện thoại:</label>
                <input type="tel" id="edit-phone" name="phone" value="<?php echo htmlspecialchars($edit_user['phone'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="dob">Ngày sinh:</label>
                <input type="date" id="edit-dob" name="dob" value="<?php echo htmlspecialchars($edit_user['dob'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="role">Vai trò:</label>
                <select id="edit-role" name="role" required>
                    <option value="staff" <?php if(isset($edit_user['role']) && $edit_user['role'] == 'staff') echo 'selected'; ?>>Nhân viên (Staff)</option>
                    <option value="admin" <?php if(isset($edit_user['role']) && $edit_user['role'] == 'admin') echo 'selected'; ?>>Quản lý (Admin)</option>
                </select>
            </div>

            <button type="submit" class="btn">Cập nhật</button>
            <a href="manage_staff.php" id="cancel-edit-btn" class="btn btn-secondary">Hủy</a>
        </form>
    </div>
</div>
<div class="container">
    <h1>Quản lý Nhân viên</h1>

    <?php echo $message; ?>

    <h2 style="margin-top: 3rem;">Danh sách Nhân viên</h2>
    <table>
        <thead>
            <tr>
                <th>Ảnh</th>
                <th>Họ Tên</th>
                <th>Tên đăng nhập</th>
                <th>Email</th>
                <th>Số điện thoại</th>
                <th>Vai trò</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($staff_list as $staff): ?>
            <tr>
                <td>
                    <?php if (!empty($staff['avatar_url'])): ?>
                        <img src="<?php echo BASE_URL; ?>/assets/images/avatars/<?php echo htmlspecialchars($staff['avatar_url']); ?>" alt="Avatar" style="width: 50px; height: 50px; object-fit: cover; border-radius: 50%;">
                    <?php else: ?>
                        (Chưa có)
                    <?php endif; ?>
                </td>
                <td><?php echo htmlspecialchars($staff['full_name']); ?></td>
                <td><?php echo htmlspecialchars($staff['username']); ?></td>
                <td><?php echo htmlspecialchars($staff['email']); ?></td>
                <td><?php echo htmlspecialchars($staff['phone'] ?? ''); ?></td>
                <td><?php echo ucfirst(htmlspecialchars($staff['role'])); ?></td>
                <td>
                    <button class="btn-action edit open-modal-btn" 
                            data-id="<?php echo $staff['id']; ?>"
                            data-username="<?php echo htmlspecialchars($staff['username']); ?>"
                            data-fullname="<?php echo htmlspecialchars($staff['full_name']); ?>"
                            data-email="<?php echo htmlspecialchars($staff['email']); ?>"
                            data-phone="<?php echo htmlspecialchars($staff['phone'] ?? ''); ?>"
                            data-dob="<?php echo htmlspecialchars($staff['dob'] ?? ''); ?>"
                            data-role="<?php echo htmlspecialchars($staff['role']); ?>"
                            data-avatar="<?php echo htmlspecialchars($staff['avatar_url'] ?? ''); ?>"
                    >Sửa</button>
                    
                    <?php if ($staff['id'] != $_SESSION['admin_id']): ?>
                    <form action="manage_staff.php" method="POST" style="display:inline-block;" onsubmit="return confirm('Bạn có chắc chắn muốn xóa nhân viên này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $staff['id']; ?>">
                        <button type="submit" class="btn-action cancel">Xóa</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
  
    const overlay = document.getElementById('modal-overlay');
    const modal = document.getElementById('profile-modal');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const cancelEditBtn = document.getElementById('cancel-edit-btn');
    const editButtons = document.querySelectorAll('.open-modal-btn');

  
    const form = document.getElementById('profile-form');
    const formId = document.getElementById('edit-id');
    const formCurrentAvatar = document.getElementById('edit-current_avatar');
    const formAvatarImg = document.getElementById('edit-avatar-img');
    const formAvatarNone = document.getElementById('edit-avatar-none');
    const formUsername = document.getElementById('edit-username');
    const formFullName = document.getElementById('edit-full_name');
    const formEmail = document.getElementById('edit-email');
    const formPhone = document.getElementById('edit-phone');
    const formDob = document.getElementById('edit-dob');
    const formRole = document.getElementById('edit-role');

  
    function openModal() {
        overlay.classList.remove('hidden');
        modal.classList.remove('hidden');
    }

   
    function closeModal() {
        overlay.classList.add('hidden');
        modal.classList.add('hidden');
        
        if (window.location.search.includes('edit_id')) {
            window.location.href = 'manage_staff.php';
        }
    }

    
    window.addEventListener('load', () => {
        <?php if ($edit_user): ?>
           
            const avatarUrl = '<?php echo $edit_user["avatar_url"] ?? ""; ?>';
            if (avatarUrl) {
                formAvatarImg.src = '<?php echo BASE_URL; ?>/assets/images/avatars/' + avatarUrl;
                formAvatarImg.style.display = 'block';
                formAvatarNone.style.display = 'none';
            } else {
                formAvatarImg.style.display = 'none';
                formAvatarNone.style.display = 'block';
            }
            openModal();
        <?php endif; ?>
    });

   
    editButtons.forEach(button => {
        button.addEventListener('click', () => {
            
            const data = button.dataset;

           
            formId.value = data.id;
            formCurrentAvatar.value = data.avatar;
            formUsername.value = data.username;
            formFullName.value = data.fullname;
            formEmail.value = data.email;
            formPhone.value = data.phone;
            formDob.value = data.dob;
            formRole.value = data.role;

         
            if (data.avatar) {
                formAvatarImg.src = '<?php echo BASE_URL; ?>/assets/images/avatars/' + data.avatar;
                formAvatarImg.style.display = 'block';
                formAvatarNone.style.display = 'none';
            } else {
                formAvatarImg.src = '';
                formAvatarImg.style.display = 'none';
                formAvatarNone.style.display = 'block';
            }

            
            openModal();
        });
    });

    
    closeModalBtn.addEventListener('click', closeModal);
    cancelEditBtn.addEventListener('click', (e) => {
        e.preventDefault(); 
        closeModal();
    });
    
    overlay.addEventListener('click', closeModal);

</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>