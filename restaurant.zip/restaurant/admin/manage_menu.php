<?php

require_once __DIR__ . '/includes/header.php';

$db = Database::getInstance();
$message = '';


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    
    if ($action == 'add' || $action == 'edit') {
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price = (float)$_POST['price'];
        $category_id = (int)$_POST['category_id'];
        $image_url = $_POST['current_image'] ?? null; 

        
        if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['image']['tmp_name'];
            $fileName = $_FILES['image']['name'];
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedfileExtensions = ['jpg', 'gif', 'png', 'jpeg'];

            if (in_array($fileExtension, $allowedfileExtensions)) {
                $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                $destPath = UPLOAD_DIR . $newFileName;

                if (move_uploaded_file($fileTmpPath, $destPath)) {
                    
                    if ($image_url && file_exists(UPLOAD_DIR . $image_url)) {
                        unlink(UPLOAD_DIR . $image_url);
                    }
                    $image_url = $newFileName;
                } else {
                    $message .= '<p class="error">Lỗi khi di chuyển file ảnh.</p>';
                }
            } else {
                $message .= '<p class="error">Chỉ chấp nhận ảnh JPG, JPEG, PNG, GIF.</p>';
            }
        }

        if ($action == 'add') {
            $sql = "INSERT INTO menu_items (name, description, price, category_id, image_url) VALUES (?, ?, ?, ?, ?)";
            $db->query($sql, [$name, $description, $price, $category_id, $image_url], "ssdis");
            $message .= '<p class="success">Thêm món ăn thành công!</p>';
        } elseif ($action == 'edit' && isset($_POST['id'])) {
            $item_id = (int)$_POST['id'];
            $sql = "UPDATE menu_items SET name = ?, description = ?, price = ?, category_id = ?, image_url = ? WHERE id = ?";
            $db->query($sql, [$name, $description, $price, $category_id, $image_url, $item_id], "ssdisi");
            $message .= '<p class="success">Cập nhật món ăn thành công!</p>';
        }
    }
    
    elseif ($action == 'delete' && isset($_POST['id'])) {
        $item_id = (int)$_POST['id'];
        
        $image_stmt = $db->query("SELECT image_url FROM menu_items WHERE id = ?", [$item_id], "i");
        $image_result = $image_stmt->get_result()->fetch_assoc();
        if ($image_result && !empty($image_result['image_url'])) {
            $image_path = UPLOAD_DIR . $image_result['image_url'];
            if (file_exists($image_path)) {
                unlink($image_path); 
            }
        }
        $db->query("DELETE FROM menu_items WHERE id = ?", [$item_id], "i");
        $message .= '<p class="success">Xóa món ăn thành công!</p>';
    }
}


$categories_stmt = $db->query("SELECT * FROM menu_categories ORDER BY name");
$categories = $categories_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$menu_items_stmt = $db->query("SELECT mi.*, mc.name as category_name FROM menu_items mi JOIN menu_categories mc ON mi.category_id = mc.id ORDER BY mc.name, mi.name");
$menu_items = $menu_items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);


$edit_item = null;
if (isset($_GET['edit_id'])) {
    $edit_id = (int)$_GET['edit_id'];
    $edit_stmt = $db->query("SELECT * FROM menu_items WHERE id = ?", [$edit_id], "i");
    $edit_item = $edit_stmt->get_result()->fetch_assoc();
}
?>

<div class="container">
    <h1>Quản lý Thực Đơn</h1>

    <?php echo $message; ?>

    <div class="form-card">
        <h2><?php echo ($edit_item ? 'Sửa' : 'Thêm') . ' Món Ăn'; ?></h2>
        <form action="manage_menu.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="<?php echo ($edit_item ? 'edit' : 'add'); ?>">
            <?php if ($edit_item): ?>
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($edit_item['id']); ?>">
                <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($edit_item['image_url']); ?>">
            <?php endif; ?>

            <div class="form-group">
                <label for="name">Tên món:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($edit_item['name'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Mô tả:</label>
                <textarea id="description" name="description" rows="3"><?php echo htmlspecialchars($edit_item['description'] ?? ''); ?></textarea>
            </div>
            <div class="form-group">
                <label for="price">Giá (VNĐ):</label>
                <input type="number" id="price" name="price" value="<?php echo htmlspecialchars($edit_item['price'] ?? ''); ?>" step="1000" min="0" required>
            </div>
            <div class="form-group">
                <label for="category_id">Danh mục:</label>
                <select id="category_id" name="category_id" required>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>" <?php if(isset($edit_item['category_id']) && $edit_item['category_id'] == $category['id']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="image">Ảnh món ăn:</label>
                <input type="file" id="image" name="image" accept="image/*">
                <?php if ($edit_item && !empty($edit_item['image_url'])): ?>
                    <p>Ảnh hiện tại: <img src="<?php echo BASE_URL; ?>/assets/images/<?php echo htmlspecialchars($edit_item['image_url']); ?>" alt="Ảnh món ăn" style="width: 100px; height: auto; vertical-align: middle;"></p>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn"><?php echo ($edit_item ? 'Cập nhật' : 'Thêm'); ?></button>
            <?php if ($edit_item): ?>
                <a href="manage_menu.php" class="btn btn-secondary">Hủy</a>
            <?php endif; ?>
        </form>
    </div>

    <h2 style="margin-top: 3rem;">Danh sách Món Ăn</h2>
    <table>
        <thead>
            <tr>
                <th>Ảnh</th>
                <th>Tên Món</th>
                <th>Danh mục</th>
                <th>Giá (VNĐ)</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($menu_items as $item): ?>
            <tr>
                <td>
                    <?php if (!empty($item['image_url'])): ?>
                        <img src="<?php echo BASE_URL; ?>/assets/images/<?php echo htmlspecialchars($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="width: 50px; height: 50px; object-fit: cover;">
                    <?php else: ?>
                        Không ảnh
                    <?php endif; ?>
                </td>
                <td><?php echo htmlspecialchars($item['name']); ?></td>
                <td><?php echo htmlspecialchars($item['category_name']); ?></td>
                <td><?php echo number_format($item['price']); ?></td>
                <td>
                    <a href="manage_menu.php?edit_id=<?php echo $item['id']; ?>" class="btn-action edit">Sửa</a>
                    <form action="manage_menu.php" method="POST" style="display:inline-block;" onsubmit="return confirm('Bạn có chắc chắn muốn xóa món ăn này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                        <button type="submit" class="btn-action cancel">Xóa</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>