<?php
// File: /core/email_service.php


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require_once __DIR__ . '/src/Exception.php';
require_once __DIR__ . '/src/PHPMailer.php';
require_once __DIR__ . '/src/SMTP.php';

function send_reservation_email($reservation_info, $ordered_items, $total_amount, $status) {
    $mail = new PHPMailer(true);

   
    $toEmail = $reservation_info['customer_email'];
    $customerName = $reservation_info['customer_name'];
    $reservationTimeFormatted = date('d/m/Y \l\ú\c H:i', strtotime($reservation_info['reservation_time']));

    try {
        
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        
        
        $mail->Username   = 'trietle3105@gmail.com'; 
        $mail->Password   = 'tmvx fqxd xutr pryu';  
        

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;
        $mail->CharSet    = 'UTF-8';

        
        $mail->setFrom('your_email@gmail.com', 'Nhà Hàng Viet VH'); 
        $mail->addAddress($toEmail, $customerName); 

       
        $logo_path = __DIR__ . '/../assets/images/logo.png';
        if (file_exists($logo_path)) {
            $mail->addEmbeddedImage($logo_path, 'logo_nhahang');
        }

        
        $mail->isHTML(true);
        
        $subject = '';
        $body    = '';
        
        $bodyHeader = "
            <div style='font-family: Arial, sans-serif; width: 600px; margin: auto; border: 1px solid #ddd;'>
                <div style='background: #f4f4f4; padding: 20px; text-align: center;'>
                    " . (file_exists($logo_path) ? "<img src='cid:logo_nhahang' alt='Logo Nhà Hàng' style='width: 150px;'>" : "<h1>Nhà Hàng Viet VH</h1>") . "
                </div>
                <div style='padding: 30px;'>
                    <h2 style='color: #333;'>Chào " . htmlspecialchars($customerName) . ",</h2>
        ";

        $bodyFooter = "
                    <p style='margin-top: 30px;'>Nếu có bất kỳ thay đổi nào hoặc yêu cầu đặc biệt, vui lòng liên hệ trực tiếp với chúng tôi qua SĐT: <b>032 8114 0857</b> (Thay SĐT của bạn).</p>
                    <p>Địa chỉ nhà hàng: 123 Đường Hoa Mai, Phường 1, Quận 2, TP. Hồ Chí Minh</p>
                    <br>
                    <p>Cảm ơn bạn đã tin tưởng và lựa chọn nhà hàng!</p>
                    <p style='font-weight: bold;'>Trân trọng,</p>
                    <p style='font-style: italic;'>Ban quản lý nhà hàng.</p>
                </div>
                <div style='background: #333; color: #fff; padding: 15px; text-align: center; font-size: 0.8rem;'>
                    &copy; " . date('Y') . " Nhà Hàng Viet VH. All rights reserved.
                </div>
            </div>
        ";
        
        $bodyContent = "
            <h3 style='color: #555;'>Chi tiết Đặt bàn (Mã: #{$reservation_info['id']})</h3>
            <table style='width: 100%; border-collapse: collapse;'>
                <tr style='border-bottom: 1px solid #eee;'><td style='padding: 8px; width: 120px;'>Thời gian:</td><td style='padding: 8px;'><b>{$reservationTimeFormatted}</b></td></tr>
                <tr style='border-bottom: 1px solid #eee;'><td style='padding: 8px;'>Số lượng khách:</td><td style='padding: 8px;'>{$reservation_info['num_guests']} người</td></tr>
                <tr style='border-bottom: 1px solid #eee;'><td style='padding: 8px;'>Bàn số:</td><td style='padding: 8px;'>{$reservation_info['table_name']}</td></tr>
                <tr style='border-bottom: 1px solid #eee;'><td style='padding: 8px;'>Ghi chú:</td><td style='padding: 8px;'>" . (empty($reservation_info['notes']) ? 'Không có' : htmlspecialchars($reservation_info['notes'])) . "</td></tr>
            </table>
        ";

        if (!empty($ordered_items)) {
            $bodyContent .= "<h3 style='color: #555; margin-top: 20px;'>Các món ăn đã chọn:</h3><ul>";
            foreach ($ordered_items as $item) {
                $bodyContent .= "<li>" . htmlspecialchars($item['item_name']) . " x " . $item['quantity'] . "</li>";
            }
            $bodyContent .= "</ul><p style='font-size: 1.1rem;'><b>Tổng tiền món ăn (dự kiến): " . number_format($total_amount) . " VNĐ</b></p>";
        }

        if ($status == 'confirmed') {
            $subject = 'Xác nhận Đặt Bàn Thành Công (Mã #' . $reservation_info['id'] . ')';
            $bodyIntro = "<p style='font-size: 1.1rem; color: #28a745;'>Nhà hàng của chúng tôi rất vui mừng thông báo đơn đặt bàn của bạn đã được <strong>XÁC NHẬN</strong>.</p>";
        } else { 
            $subject = 'Thông báo Hủy Đơn Đặt Bàn (Mã #' . $reservation_info['id'] . ')';
            $bodyIntro = "<p style='font-size: 1.1rem; color: #dc3545;'>Chúng tôi rất tiếc phải thông báo đơn đặt bàn của bạn đã bị <strong>TỪ CHỐI / HỦY</strong>.</p><p>Nếu bạn không chủ động hủy, có thể do lịch đặt đã bị trùng hoặc quá tải. Vui lòng thử lại vào một thời điểm khác.</p>";
        }

        $mail->Subject = $subject;
        $mail->Body    = $bodyHeader . $bodyIntro . $bodyContent . $bodyFooter;
        
        $mail->send();
        return true; 
    } catch (Exception $e) {
       
        return false; 
    }
}