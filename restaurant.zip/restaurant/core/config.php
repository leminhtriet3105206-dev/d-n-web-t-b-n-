<?php

if (defined('CONFIG_LOADED')) {
    return;
}
define('CONFIG_LOADED', true);


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_restaurant');

define('BASE_URL', 'http://localhost/restaurant');

define('UPLOAD_DIR', __DIR__ . '/../assets/images/');

define('AVATAR_UPLOAD_DIR', __DIR__ . '/../assets/images/avatars/');