<?php

require_once '../core/config.php';


include 'includes/header.php';
?>
<div class="container">
    <div class="hero">
        <h1>Chào mừng đến với Nhà Hàng VietVH</h1>
        <p>Trải nghiệm ẩm thực tuyệt vời với không gian sang trọng và ấm cúng.</p>
        <a href="reservation.php" class="btn">Đặt Bàn Ngay</a>
    </div>
</div>
<?php include 'includes/footer.php'; ?> 