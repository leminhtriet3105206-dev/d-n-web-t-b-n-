<?php
// File: /public/reservation.php

require_once '../core/config.php';
require_once '../core/database.php';

$db = Database::getInstance();

$tables_stmt = $db->query("SELECT * FROM tables ORDER BY name");
$tables = $tables_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$menu_items_stmt = $db->query("SELECT * FROM menu_items ORDER BY name");
$menu_items = $menu_items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['customer_name']);
    $email = trim($_POST['customer_email']);
    $phone = trim($_POST['customer_phone']);
    $table_id = $_POST['table_id'];
    $datetime_str = $_POST['reservation_time']; 
    $guests = $_POST['num_guests'];
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
    $selected_menu_items = $_POST['menu_item_quantity'] ?? [];

    if (empty($name) || empty($email) || empty($phone) || empty($table_id) || empty($datetime_str) || empty($guests)) {
        $message = '<p class="error">Vui lòng điền đầy đủ thông tin bắt buộc (*).</p>';
    } else {
        

        $reservation_time_formatted = date('Y-m-d H:i:s'); 

        if (!empty($datetime_str)) {
            $clean_str = str_replace('T', ' ', $datetime_str);
            $timestamp = strtotime($clean_str);
            if ($timestamp !== false && $timestamp > 0 && (int)date('Y', $timestamp) > 2020) {
                $reservation_time_formatted = date('Y-m-d H:i:s', $timestamp);
            }
        }

        
        $new_start = $reservation_time_formatted;
        $new_end = date('Y-m-d H:i:s', strtotime($new_start . ' + 90 minutes'));

        $check_sql = "
            SELECT COUNT(*) as conflict_count 
            FROM reservations 
            WHERE table_id = ? 
            AND status != 'cancelled' 
            AND (
                reservation_time < ? 
                AND DATE_ADD(reservation_time, INTERVAL 90 MINUTE) > ?
            )
        ";
        
        $check_stmt = $db->query($check_sql, [$table_id, $new_end, $new_start], "iss");
        $conflict = $check_stmt->get_result()->fetch_assoc()['conflict_count'];

        if ($conflict > 0) {
            $message = '<p class="error">Rất tiếc, bàn này đã có khách đặt trong khung giờ bạn chọn. Vui lòng chọn giờ khác hoặc bàn khác.</p>';
        } else {
           
            $sql_reservation = "INSERT INTO reservations (customer_name, customer_email, customer_phone, table_id, reservation_time, num_guests, notes) VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            
            $stmt_reservation = $db->query($sql_reservation, [$name, $email, $phone, $table_id, $reservation_time_formatted, $guests, $notes], "sssisis");

            if ($stmt_reservation) {
                $reservation_id = $db->getConnection()->insert_id;
                foreach ($selected_menu_items as $menu_item_id => $quantity) {
                    $quantity = (int)$quantity;
                    if ($quantity > 0) {
                        $item_price_stmt = $db->query("SELECT price FROM menu_items WHERE id = ?", [$menu_item_id], "i");
                        $item_price_result = $item_price_stmt->get_result()->fetch_assoc();
                        if ($item_price_result) {
                            $price_at_reservation = $item_price_result['price'];
                            $sql_item = "INSERT INTO reservation_items (reservation_id, menu_item_id, quantity, price_at_reservation) VALUES (?, ?, ?, ?)";
                            $db->query($sql_item, [$reservation_id, $menu_item_id, $quantity, $price_at_reservation], "iiid");
                        }
                    }
                }
                
                
                $time_display = date('H:i d/m/Y', strtotime($reservation_time_formatted));
                $hold_until = date('H:i', strtotime($reservation_time_formatted . ' + 30 minutes'));

                $message = '
                <div class="success-box">
                    <h3>✅ Đặt bàn thành công!</h3>
                    <p>Cảm ơn bạn đã đặt bàn. Chúng tôi sẽ sớm liên hệ để xác nhận.</p>
                    <hr>
                    <h4>⚠️ QUY ĐỊNH NHÀ HÀNG:</h4>
                    <ul style="text-align: left; margin-top: 10px;">
                        <li><strong>Thời gian giữ bàn:</strong> Tối đa <strong>30 phút</strong> tính từ <strong>giờ hẹn</strong>.<br><em>(Ví dụ: Hẹn lúc <b>'.$time_display.'</b>, giữ đến <b>'.$hold_until.'</b>).</em></li>
                        <li><strong>Thời gian dùng bữa:</strong> Tối đa <strong>90 phút</strong>/lượt.</li>
                    </ul>
                </div>';
            } else {
                $message = '<p class="error">Có lỗi xảy ra. Vui lòng thử lại.</p>';
            }
        }
    }
}

include 'includes/header.php';
?>

<style>
    .success-box { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
    .success-box h3 { margin-top: 0; color: #155724; }
    .success-box h4 { margin-bottom: 5px; margin-top: 15px; color: #856404; }
    .success-box hr { border: 0; border-top: 1px solid #c3e6cb; }
    .success-box ul li { margin-bottom: 8px; line-height: 1.5; }
</style>

<div class="container">
    <h1>Đặt Bàn</h1>
    <?php echo $message; ?>
    
    <?php if (strpos($message, 'success-box') === false): ?>
    <form class="reservation-form" action="reservation.php" method="POST">
        <h3>Thông Tin Liên Hệ</h3>
        <div class="form-group"><label>Họ và Tên (*):</label><input type="text" id="customer_name" name="customer_name" required></div>
        <div class="form-group"><label>Số Điện Thoại (*):</label><input type="tel" id="customer_phone" name="customer_phone" required></div>
        <div class="form-group"><label>Email (*):</label><input type="email" id="customer_email" name="customer_email" required></div>

        <h3>Chi Tiết Đặt Bàn</h3>
        <div class="form-group"><label>Số Lượng Khách (*):</label><input type="number" id="num_guests" name="num_guests" min="1" required></div>
        <div class="form-group"><label>Ngày và Giờ (*):</label><input type="datetime-local" id="reservation_time" name="reservation_time" value="<?php echo date('Y-m-d\TH:i'); ?>" required></div>
        <div class="form-group">
            <label>Chọn Bàn (*):</label>
            <select id="table_id" name="table_id" required>
                <option value="">-- Vui lòng chọn bàn --</option>
                <?php foreach ($tables as $table): ?>
                    <option value="<?php echo $table['id']; ?>"><?php echo htmlspecialchars($table['name']); ?> (Tối đa <?php echo $table['capacity']; ?> người)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>Ghi Chú (Tùy chọn):</label><textarea id="notes" name="notes" rows="3"></textarea></div>

        <h3>Chọn Món Ăn (Tùy chọn)</h3>
        <div class="menu-selection-list">
            <?php foreach ($menu_items as $item): ?>
                <div class="menu-selection-item">
                    <?php if (!empty($item['image_url'])): ?><img src="<?php echo BASE_URL; ?>/assets/images/<?php echo htmlspecialchars($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>"><?php endif; ?>
                    <h4><?php echo htmlspecialchars($item['name']); ?> - <?php echo number_format($item['price']); ?> VNĐ</h4>
                    <div class="quantity-control"><label>SL:</label><input type="number" id="qty_<?php echo $item['id']; ?>" name="menu_item_quantity[<?php echo $item['id']; ?>]" value="0" min="0"></div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <button type="submit" class="btn">Gửi Đặt Bàn</button>
    </form>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>