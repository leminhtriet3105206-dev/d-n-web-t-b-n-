<?php

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nhà Hàng VietVH</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="<?php echo BASE_URL; ?>/public/index.php" class="logo">Nhà Hàng VietVH</a>
           <nav>
                <ul>
                    <li><a href="<?php echo BASE_URL; ?>/public/index.php">Trang Chủ</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/public/menu.php">Thực Đơn</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/public/reservation.php">Đặt Bàn</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/public/contact.php">Liên Hệ</a></li> 
                </ul>
            </nav>
        </div>
    </header>
    <main>