</main>
    <footer>
        <div class="container">
            <p>&copy; 2025 Nhà Hàng VietVH. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>