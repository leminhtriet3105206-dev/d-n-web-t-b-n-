<?php

require_once '../core/config.php';


include 'includes/header.php';
?>

<div class="container">
    <div class="contact-info">
        <h1>Liên Hệ Với Chúng Tôi</h1>
        <p>Chúng tôi luôn sẵn sàng lắng nghe bạn. Vui lòng liên hệ qua các thông tin dưới đây hoặc đến trực tiếp nhà hàng.</p>
        
        <ul>
            <li>
                <strong>Địa chỉ:</strong>
                <p>123 Đường Hoa Mai, Phường 1, Quận 2, TP. Hồ Chí Minh</p>
            </li>
            <li>
                <strong>Số điện thoại đặt bàn:</strong>
                <p>(032) 8114 0857</p>
            </li>
            <li>
                <strong>Email:</strong>
                <p>NhahangVietVH@gmail.com</p>
            </li>
            <li>
                <strong>Giờ mở cửa:</strong>
                <p>Thứ 2 - Chủ Nhật: 10:00 SA - 22:00 TỐI</p>
            </li>
        </ul>
    </div>
</div>

<?php include 'includes/footer.php'; ?>