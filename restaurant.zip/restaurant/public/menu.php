<?php

require_once '../core/config.php';
require_once '../core/database.php';

$db = Database::getInstance();
$categories_stmt = $db->query("SELECT * FROM menu_categories ORDER BY id");
$categories = $categories_stmt->get_result()->fetch_all(MYSQLI_ASSOC);


include 'includes/header.php';
?>
<div class="container">
    <h1>Thực Đơn Của Chúng Tôi</h1>

    <?php foreach ($categories as $category): ?>
        <h2 class="category-title"><?php echo htmlspecialchars($category['name']); ?></h2>
        <div class="menu-list">
            <?php
            $items_stmt = $db->query("SELECT * FROM menu_items WHERE category_id = ?", [$category['id']], "i");
            $items = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            ?>
            <?php foreach ($items as $item): ?>
                <div class="menu-item">
                    <?php if (!empty($item['image_url'])): ?>
                        <img src="<?php echo BASE_URL; ?>/assets/images/<?php echo htmlspecialchars($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="menu-item-image">
                    <?php endif; ?>
                    <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                    <p><?php echo htmlspecialchars($item['description']); ?></p>
                    <span class="price"><?php echo number_format($item['price']); ?> VNĐ</span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>

</div>
<?php include 'includes/footer.php'; ?>